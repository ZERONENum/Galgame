window.CHAPTER_route_mizuno = {
  meta: {
    title: "水野真理路线 · 验算星星",
    subtitle: "她是那个替他把错误折成花的人",
    tag: "路线 · 水野",
    bgm: "晚自习安静",
    bg: "教室课桌特写"
  },
  lines: [
    { text: "一月。毕业册材料归档前的最后一次模拟考。" },
    { text: "这张成绩单会夹进升学资料里，也会决定高桥老师能不能少叹几口气。" },

    { bg: "教室暖光", text: "成绩发下来那天，教室里安静得能听见红笔划过纸面的声音。" },
    { char: { center: "高桥惠子微笑" }, speaker: "高桥老师", text: "林栖。" },
    { char: { center: "高桥惠子微笑" }, speaker: "高桥老师", text: "九十三。" },

    { text: "全班再一次安静了。" },

    { char: { right: "学生A" }, speaker: "学生A", text: "……九十三？！他是不是作弊了？" },
    { char: { right: "学生B" }, speaker: "学生B", text: "不可能。水野盯了他一年。" },
    { char: { right: "学生C" }, speaker: "学生C", text: "这哪是错题本……这是外挂啊。" },

    { char: { right: "水野真理温柔" }, speaker: "水野真理", text: "……" },
    { text: "她低头继续做题。" },
    { text: "但她的笔尖，在草稿纸上抖了一下。" },
    { speaker: "林栖", text: "水野。" },
    { char: { right: "水野真理若有所思" }, speaker: "水野真理", text: "什么事。" },
    { speaker: "林栖", text: "你刚才笑了。" },
    { char: { right: "水野真理坚定" }, speaker: "水野真理", text: "没有。" },
    { speaker: "林栖", text: "左边嘴角，三毫米。" },
    { char: { right: "水野真理若有所思" }, speaker: "水野真理", text: "你观察这种东西做什么。" },
    { speaker: "林栖", text: "因为你观察我。" },
    { text: "水野真理的笔尖停在等号前。" },
    { speaker: "林栖", text: "很公平。" },
    { text: "他说公平的时候，语气很淡，却像把她藏了一年的小心思直接摆到了课桌中央。" },

    { text: "" },
    { text: "放学后。" },
    { text: "她抱着一摞作业本，往教师办公室走。" },

    { text: "林栖从走廊的另一端走过来。" },
    { text: "他停在她面前。" },

    { speaker: "林栖", text: "水野。" },
    { char: { right: "水野真理温柔" }, speaker: "水野真理", text: "……嗯。" },
    { speaker: "林栖", text: "谢谢你。别急着装没听见。" },

    { char: { right: "水野真理若有所思" }, speaker: "水野真理", text: "……你之前说过了。" },
    { speaker: "林栖", text: "嗯。你那次假装只是借草稿纸，其实把解法写了半页。" },
    { speaker: "林栖", text: "再说一次。" },
    { char: { right: "水野真理坚定" }, speaker: "水野真理", text: "为什么。" },
    { speaker: "林栖", text: "因为你会装作不在意。" },
    { char: { right: "水野真理若有所思" }, speaker: "水野真理", text: "我没有装。" },
    { speaker: "林栖", text: "你刚才把作业本抱紧了。" },
    { text: "水野真理低头，发现自己确实把那摞作业本抱得很紧。" },
    { speaker: "林栖", text: "你很难骗。" },
    { speaker: "林栖", text: "但也不是骗不了。" },
    { char: { right: "水野真理坚定" }, speaker: "水野真理", text: "林栖同学。" },
    { speaker: "林栖", text: "嗯。" },
    { char: { right: "水野真理若有所思" }, speaker: "水野真理", text: "你有时候说话很恶劣。" },
    { speaker: "林栖", text: "你还是听完了。" },
    { text: "她没有办法反驳。" },

    { text: "他从口袋里掏出一张纸。" },
    { text: "一张——被折过的纸。" },
    { text: "纸边被压得很平，像被书本夹过一整夜。" },
    { text: "上面用红笔，画了——" },
    { text: "三十八颗小星星。" },
    { char: { right: "水野真理若有所思" }, speaker: "水野真理", text: "这不是我的草稿纸吗？" },
    { speaker: "林栖", text: "嗯。" },
    { speaker: "林栖", text: "你扫雷那天借我的。" },
    { bg: "教室课桌特写", text: "那天下午的自习课，窗外的阳光斜斜压在课桌上。" },
    { text: "水野真理把一张草稿纸推给他，上面已经画满了方格、数字和细小的标记。" },
    { char: { right: "水野真理坚定" }, speaker: "水野真理", text: "这不是游戏。" },
    { char: { right: "水野真理坚定" }, speaker: "水野真理", text: "这是概率判断。" },
    { speaker: "林栖", text: "名字叫扫雷。你把游戏讲成论文的样子，很浪费才能。" },
    { char: { right: "水野真理若有所思" }, speaker: "水野真理", text: "那也是概率判断。" },
    { cg: "自习课扫雷草稿纸", caption: "自习课的草稿纸" },
    { speaker: "旁白", text: "草稿纸上挤满了数字、箭头和小小的叉。\n林栖在空白角落折了一颗星。\n水野真理装作没看见，却在题号旁边画了一个很小的圆。" },
    { bg: "教室暖光", text: "现在，那张草稿纸重新回到她眼前。" },
    { text: "上面的方格被折进纸缝里，只剩星星一颗一颗排开。" },

    { char: { right: "水野真理坚定" }, speaker: "水野真理", text: "……这是什么。" },
    { speaker: "林栖", text: "三十七道题。" },
    { speaker: "林栖", text: "——一颗星星，一道题。" },
    { speaker: "林栖", text: "最后一颗——" },
    { speaker: "林栖", text: "是你。别皱眉，我知道这句话很不严谨。" },
    { char: { right: "水野真理坚定" }, speaker: "水野真理", text: "这不符合计数规则。" },
    { speaker: "林栖", text: "那你改。" },
    { char: { right: "水野真理若有所思" }, speaker: "水野真理", text: "……" },
    { speaker: "林栖", text: "你最擅长改错。" },
    { text: "那一瞬间，水野真理忽然明白，他不是不知道这句话有多过分。" },
    { text: "他只是把「改错」两个字递给她，像递出一把钥匙。" },
    { char: { right: "水野真理微笑" }, speaker: "水野真理", text: "那我改。" },
    { char: { right: "水野真理微笑" }, speaker: "水野真理", text: "第三十九颗，不是我。" },
    { char: { right: "水野真理温柔" }, speaker: "水野真理", text: "是你终于愿意把答案交出来。" },

    { char: { right: "水野真理坚定" }, speaker: "水野真理", text: "……" },

    { text: "她站在原地。" },
    { text: "那摞作业本，几乎从她怀里滑下来。" },

    { text: "他把那张画了三十八颗星星的纸，" },
    { text: "轻轻塞进她最上面一本作业本里。" },

    { speaker: "林栖", text: "第四季度的复习材料，我自己整理好了。" },
    { speaker: "林栖", text: "放在你抽屉里了。" },
    { speaker: "林栖", text: "里面也有。你想看的话，现在就可以去翻。" },

    { char: { right: "水野真理若有所思" }, speaker: "水野真理", text: "……里面也有什么。" },
    { speaker: "林栖", text: "星星。" },
    { speaker: "林栖", text: "第三十九颗。" },

    { text: "第三十九颗小星星，在夕阳下泛着柔和的红色。它不像答案，更像她一整年替他留下的某个标记。" },

  ],
  ending: {
    title: "水野真理 · 验算星星",
    text: "她替他把错误，一张一张，折成了花。\n他把那些花，一颗一颗，画成了星星。\n三十七道题。三十八颗星。\n——第三十九颗，是她自己。",
    _route: "mizuno"
  }
};
